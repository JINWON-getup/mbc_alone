package controller.admin.Medic;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.doctor.DoctorDAO;
import model.doctor.DoctorDTO;
import model.medic.MedicDAO;
import model.medic.MedicDTO;

public class MedicUpdate implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String medic = request.getParameter("medic");
		
		MedicDAO dao = new MedicDAO();
		MedicDTO dto = dao.getMedicInfo(medic);
		
		request.setAttribute("dto", dto);
		
		return "admin/medic_update";
	}
}