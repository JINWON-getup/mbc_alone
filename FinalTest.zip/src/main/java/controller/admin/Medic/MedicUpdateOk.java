package controller.admin.Medic;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.doctor.DoctorDAO;
import model.doctor.DoctorDTO;
import model.medic.MedicDAO;
import model.medic.MedicDTO;

public class MedicUpdateOk implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String name = request.getParameter("name");
		String medic = request.getParameter("medic");
		String room_num = request.getParameter("room_num");
		
		MedicDTO dto = new MedicDTO();
		dto.setName(name);
		dto.setMedic(medic);
		dto.setRoom_num(room_num);
		
		MedicDAO dao = new MedicDAO();
		int n = dao.updateMedic(dto);
		
		String viewPage = null;
		if(n>0) {
			System.out.println("진료과 수정 완료");
			viewPage = "medicList.do";
		} else {
			System.out.println("진료과 수정 실패");
			viewPage = "admin/medic_update";
		}
		return viewPage;
	}
}