package controller.admin.Medic;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.medic.MedicDAO;
import model.medic.MedicDTO;

public class MedicList implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		MedicDAO dao = new MedicDAO();
		ArrayList<MedicDTO> list
			= dao.medicList();
		
		System.out.println(list);
		request.setAttribute("list", list);
		
		return "admin/medic_list";
	}
}