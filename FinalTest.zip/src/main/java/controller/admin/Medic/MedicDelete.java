package controller.admin.Medic;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.doctor.DoctorDAO;
import model.medic.MedicDAO;
import model.user.PatientDAO;

public class MedicDelete implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String medic = request.getParameter("medic");
		
		MedicDAO dao = new MedicDAO();
		int n = dao.deleteMedic(medic);
		
		String viewPage = null;
		if(n>0) {
			request.setAttribute("msg", "진료과 삭제 완료");
			viewPage = "medicList.do";
		} else {
			System.out.println("진료과 삭제 실패");
			viewPage = "admin/medic_list";
		}
		return viewPage;
	}
}
