package controller.admin.User;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.user.PatientDAO;
import model.user.PatientDTO;

public class UserUpdateOk implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String tel = request.getParameter("tel");
		String email = request.getParameter("email");
		String addr = request.getParameter("addr");
		
		PatientDTO dto = new PatientDTO();
		dto.setId(id);
		dto.setPw(pw);
		dto.setTel(tel);
		dto.setEmail(email);
		dto.setAddr(addr);
		
		PatientDAO dao = new PatientDAO();
		int n = dao.updatePatient(dto);
		
		String viewPage = null;
		if(n>0) {
			System.out.println("회원수정 완료");
			viewPage = "userList.do";
		} else {
			System.out.println("회원수정 실패");
			viewPage = "admin/user_update";
		}
		return viewPage;
	}
}