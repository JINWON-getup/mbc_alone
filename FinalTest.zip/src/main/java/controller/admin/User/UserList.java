package controller.admin.User;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.user.PatientDAO;
import model.user.PatientDTO;

public class UserList implements Controller {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		PatientDAO dao = new PatientDAO();
		ArrayList<PatientDTO> list
			= dao.patientList();
		
		System.out.println(list);
		request.setAttribute("list", list);
		
		return "admin/user_list";
	}
}