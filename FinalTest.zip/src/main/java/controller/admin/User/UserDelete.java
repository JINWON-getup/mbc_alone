package controller.admin.User;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.user.PatientDAO;

public class UserDelete implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String id = request.getParameter("id");
		
		PatientDAO dao = new PatientDAO();
		int n = dao.deletePatient(id);
		
		String viewPage = null;
		if(n>0) {
			request.setAttribute("msg", "회원 삭제 완료");
			viewPage = "userList.do";
		} else {
			System.out.println("회원 삭제 실패");
			viewPage = "admin/user_list";
		}
		return viewPage;
	}
}