package controller.admin.User;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.medic.MedicDAO;
import model.medic.MedicDTO;

public class Reservation implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		MedicDAO dao = new MedicDAO();
		ArrayList<MedicDTO> medicList = dao.medicList();
		System.out.println(medicList);
		
		request.setAttribute("medicList", medicList);
		
		return "user/reservation";
	}
}