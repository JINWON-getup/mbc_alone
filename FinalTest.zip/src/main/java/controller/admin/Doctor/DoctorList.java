package controller.admin.Doctor;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.doctor.DoctorDAO;
import model.doctor.DoctorDTO;

public class DoctorList implements Controller {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		DoctorDAO dao = new DoctorDAO();
		ArrayList<DoctorDTO> list
			= dao.doctorList();
		
		System.out.println(list);
		request.setAttribute("list", list);
		
		return "admin/doctor_list";
	}

}