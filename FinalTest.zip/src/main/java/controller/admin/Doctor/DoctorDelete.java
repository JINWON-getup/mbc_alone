package controller.admin.Doctor;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.doctor.DoctorDAO;
import model.user.PatientDAO;

public class DoctorDelete implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int dno = Integer.valueOf(request.getParameter("dno"));
		
		DoctorDAO dao = new DoctorDAO();
		int n = dao.deleteDoctor(dno);
		
		String viewPage = null;
		if(n>0) {
			request.setAttribute("msg", "의료진 삭제 완료");
			viewPage = "doctorList.do";
		} else {
			System.out.println("의료진 삭제 실패");
			viewPage = "admin/doctor_list";
		}
		return viewPage;
	}
}