package controller.admin.Doctor;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.doctor.DoctorDAO;
import model.doctor.DoctorDTO;

public class DoctorUpdate implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int dno = Integer.valueOf(request.getParameter("dno"));
		
		DoctorDAO dao = new DoctorDAO();
		DoctorDTO dto = dao.getDoctorInfo(dno);
		
		request.setAttribute("dto", dto);
		
		return "admin/doctor_update";
	}
}