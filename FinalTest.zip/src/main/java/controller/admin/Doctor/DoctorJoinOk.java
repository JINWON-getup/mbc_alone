package controller.admin.Doctor;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.doctor.DoctorDAO;
import model.doctor.DoctorDTO;

public class DoctorJoinOk implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String name = request.getParameter("name");
		String medic = request.getParameter("medic");
		String room_num = request.getParameter("room_num");
		String tel = request.getParameter("tel");
		
		DoctorDTO dto
			= new DoctorDTO(name, medic, room_num, tel);
		
		DoctorDAO dao = new DoctorDAO();
		int n = dao.doctorInsert(dto);
		
		String viewPage = null;
		if(n>0) {
			System.out.println("등록 완료");
			request.setAttribute("msg", "등록 완료");
			viewPage = "doctorList.do";
		} else {
			System.out.println("등록 실패");
			viewPage = "admin/doctor_join";
		}
		return viewPage;
	}	
}