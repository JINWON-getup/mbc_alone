package controller.admin.Doctor;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.doctor.DoctorDAO;
import model.doctor.DoctorDTO;

public class DoctorUpdateOk implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int dno = Integer.parseInt(request.getParameter("dno"));
		String medic = request.getParameter("medic");
		String room_num = request.getParameter("room_num");
		String tel = request.getParameter("tel");
		
		DoctorDTO dto = new DoctorDTO();
		dto.setDno(dno);
		dto.setMedic(medic);
		dto.setRoom_num(room_num);
		dto.setTel(tel);
		
		DoctorDAO  dao = new DoctorDAO();
		int n = dao.updateDoctor(dto);
		
		String viewPage = null;
		if(n>0) {
			System.out.println("의료진 수정 완료");
			viewPage = "doctorList.do";
		} else {
			System.out.println("의료진 수정 실패");
			viewPage = "admin/doctor_update";
		}
		return viewPage;
	}
}