package controller.admin.Reservation;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.reservation.ReservationDAO;
import model.reservation.ReservationDTO;

public class ReservationUpdateOk implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int r_num = Integer.valueOf(request.getParameter("r_num"));
		String medic = request.getParameter("medic");
		String r_day = request.getParameter("r_day");
		String detail = request.getParameter("detail");
		
		ReservationDTO dto = new ReservationDTO();
		dto.setR_num(r_num);
		dto.setMedic(medic);
		dto.setR_day(r_day);
		dto.setDetail(detail);

		
		ReservationDAO dao = new ReservationDAO();
		int n = dao.updateReservation(dto);
		
		String viewPage = null;
		if(n>0) {
			System.out.println("수정 완료");
			viewPage = "/reservationList.do";
		} else {
			System.out.println("수정 실패");
			viewPage = "admin/reservation_update";
		}
		return viewPage;
	}
}