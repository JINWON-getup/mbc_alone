package controller.admin.Reservation;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.reservation.ReservationDAO;
import model.reservation.ReservationDTO;

public class ReservationUpdate implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int r_num = Integer.valueOf(request.getParameter("r_num"));
		
		ReservationDAO dao = new ReservationDAO();
		ReservationDTO dto = dao.getReservationInfo(r_num);
		
		request.setAttribute("dto", dto);
		
		return "admin/reservation_update";
	}
}