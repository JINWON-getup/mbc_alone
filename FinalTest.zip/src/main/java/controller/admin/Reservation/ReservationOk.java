package controller.admin.Reservation;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.reservation.ReservationDAO;
import model.reservation.ReservationDTO;

public class ReservationOk implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String name = request.getParameter("name");
		String resident_num = request.getParameter("resident_num");
		String tel = request.getParameter("tel");
		String address = request.getParameter("address");
		String medic = request.getParameter("medic");
		String r_day = request.getParameter("r_day");
		String detail = request.getParameter("detail");
		
		
		ReservationDTO dto
			= new ReservationDTO(name, resident_num, tel, address, medic, r_day, detail);
		
		
		ReservationDAO dao = new ReservationDAO();
		int n = dao.reservationInsert(dto);
		
		String viewPage = null;
		if(n>0) {
			System.out.println("예약 완료");
			viewPage = "home.do";
		} else {
			System.out.println("예약 실패");
			viewPage = "user/reservation";
		}
		return viewPage;
	}
}