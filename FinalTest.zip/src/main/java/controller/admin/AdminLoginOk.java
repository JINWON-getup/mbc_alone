package controller.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Controller;
import model.admin.AdminDAO;
import model.admin.AdminDTO;

public class AdminLoginOk implements Controller {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		
		AdminDAO dao = new AdminDAO();
		int n = dao.adminCheck(id, pwd);
		
		String viewPage = null;
		
		HttpSession session = request.getSession();
		
		if(n == AdminDAO.ADMIN_LOGIN_SUCCESS) {
			AdminDTO dto = dao.getAdminInfo(id);
			String name = dto.getName();
			
			session.setAttribute("id", id);
			session.setAttribute("name", name);
			session.setAttribute("mode", "admin");
			
		} else if(n == AdminDAO.ADMIN_LOGIN_PWD_FAIL){
			request.setAttribute("loginErr", "pwErr");
		} else if(n == AdminDAO.ADMIN_LOGIN_ID_NOT){
			request.setAttribute("loginErr", "idErr");			
		}
		
		if(request.getAttribute("loginErr") != null) {
			viewPage = "admin/ad_login";
		} else {
			viewPage = "admin/ad_main";
		}		
		return viewPage;
	}
}