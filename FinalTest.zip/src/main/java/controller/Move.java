package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Move implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String cmd = (String)request.getAttribute("cmd");
		
		String viewPage = null;
		if(cmd.equals("/adminLogin.do")) {
			viewPage = "admin/ad_login";
		} else if(cmd.equals("/adminMain.do")) {
			viewPage = "admin/ad_main";
		} else if(cmd.equals("/doctorJoin.do")) {
			viewPage = "admin/doctor_join";
		} else if(cmd.equals("/medicJoin.do")) {
			viewPage = "admin/medic_join";
		} else if(cmd.equals("/userJoin.do")) {
			viewPage = "user/join";
		} else if(cmd.equals("/userLogin.do")) {
			viewPage = "user/login";
		} 
		return viewPage;
	}	
}