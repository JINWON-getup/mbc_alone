package controller.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Controller;
import model.user.PatientDAO;
import model.user.PatientDTO;

public class UserLoginOk implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		
		PatientDAO dao = new PatientDAO();
		int n = dao.userCheck(id, pwd);
		
		String viewPage = null;
		
		HttpSession session = request.getSession();
		
		if(n == PatientDAO.MEMBER_LOGIN_SUCCESS) {
			PatientDTO dto = dao.getUserInfo(id);
			String name = dto.getName();
			
			session.setAttribute("id", id);
			session.setAttribute("name", name);
			session.setAttribute("mode", "user");			
		} else if(n == PatientDAO.MEMBER_LOGIN_PWD_FAIL) {
			request.setAttribute("loginErr", "pwErr");
		} else if(n == PatientDAO.MEMBER_LOGIN_ID_NOT) {
			request.setAttribute("loginErr", "idErr");
		}
		
		if(request.getAttribute("loginErr") != null) {
			viewPage = "user/login";
		} else {
			viewPage = "main/main";
		}
		return viewPage;
	}
}