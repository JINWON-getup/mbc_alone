package controller.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import model.user.PatientDAO;
import model.user.PatientDTO;

public class UserJoinOk implements Controller{

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String tel = request.getParameter("tel");
		String email = request.getParameter("email");
		String addr = request.getParameter("addr");
		
		PatientDTO dto
			= new PatientDTO(id, pw, name, tel, email, addr, null);
		
		PatientDAO dao = new PatientDAO();
		int n = dao.userInsert(dto);
		
		String viewPage = null;
		if(n>0) {
			System.out.println("회원가입 완료");
			request.setAttribute("msg", "회원가입 완료");
			viewPage = "user/login";
		} else {
			System.out.println("회원가입 실패");
			viewPage = "user/join";
		}
		return viewPage;
	}
}