package frontController;

import java.util.HashMap;
import java.util.Map;

import controller.Controller;
import controller.Move;
import controller.admin.AdminLoginOk;
import controller.admin.AdminLogout;
import controller.admin.Doctor.DoctorDelete;
import controller.admin.Doctor.DoctorJoinOk;
import controller.admin.Doctor.DoctorList;
import controller.admin.Doctor.DoctorUpdate;
import controller.admin.Doctor.DoctorUpdateOk;
import controller.admin.Medic.MedicDelete;
import controller.admin.Medic.MedicJoinOk;
import controller.admin.Medic.MedicList;
import controller.admin.Medic.MedicUpdate;
import controller.admin.Medic.MedicUpdateOk;
import controller.admin.Reservation.ReservationDelete;
import controller.admin.Reservation.ReservationList;
import controller.admin.Reservation.ReservationOk;
import controller.admin.Reservation.ReservationUpdate;
import controller.admin.Reservation.ReservationUpdateOk;
import controller.admin.User.Reservation;
import controller.admin.User.UserDelete;
import controller.admin.User.UserList;
import controller.admin.User.UserUpdate;
import controller.admin.User.UserUpdateOk;
import controller.user.Home;
import controller.user.UserJoinOk;
import controller.user.UserLoginOk;
import controller.user.UserLogout;

public class ActionMapping {
	private Map<String, Controller> actionMap = new HashMap<>();

	public ActionMapping() {
		// ---------- 관리자 ----------
		// 관리자 홈
		actionMap.put("/adminMain.do", new Move());
		
		// 관리자 로그인
		actionMap.put("/adminLogin.do", new Move());
		actionMap.put("/adminLoginOk.do", new AdminLoginOk());
		actionMap.put("/adminLogout.do", new AdminLogout());
		
		// 회원 관리
		actionMap.put("/userList.do", new UserList());
		actionMap.put("/userUpdate.do", new UserUpdate());
		actionMap.put("/userUpdateOk.do", new UserUpdateOk());
		actionMap.put("/userDelete.do", new UserDelete());
		
		// 예약 정보
		actionMap.put("/reservationList.do", new ReservationList());
		actionMap.put("/reservationUpdate.do", new ReservationUpdate());
		actionMap.put("/reservationUpdateOk.do", new ReservationUpdateOk());
		actionMap.put("/reservationDelete.do", new ReservationDelete());
						
		// 의료진
		actionMap.put("/doctorList.do", new DoctorList());
		actionMap.put("/doctorJoin.do", new Move());
		actionMap.put("/doctorJoinOk.do", new DoctorJoinOk());
		actionMap.put("/doctorUpdate.do", new DoctorUpdate());		
		actionMap.put("/doctorUpdateOk.do", new DoctorUpdateOk());		
		actionMap.put("/doctorDelete.do", new DoctorDelete());
		
		// 진료과
		actionMap.put("/medicList.do", new MedicList());
		actionMap.put("/medicJoin.do", new Move());
		actionMap.put("/medicJoinOk.do", new MedicJoinOk());
		actionMap.put("/medicUpdate.do", new MedicUpdate());
		actionMap.put("/medicUpdateOk.do", new MedicUpdateOk());
		actionMap.put("/medicDelete.do", new MedicDelete());
		
		// ---------- 회원 ----------
		// 회원 홈
		actionMap.put("/", new Home());		
		actionMap.put("/home.do", new Home());
		
		// 회원 가입
		actionMap.put("/userJoin.do", new Move());
		actionMap.put("/userJoinOk.do", new UserJoinOk());
		
		// 회원 로그인
		actionMap.put("/userLogin.do", new Move());
		actionMap.put("/userLoginOk.do", new UserLoginOk());
		actionMap.put("/userLogout.do", new UserLogout());
		
		// 예약
		actionMap.put("/reservation.do", new Reservation());		
		actionMap.put("/reservationOk.do", new ReservationOk());		
	}
	
	public Controller getController(String cmd) {
		return actionMap.get(cmd);
	}
}	