package model.reservation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.DbConn;
import model.doctor.DoctorDTO;
import model.medic.MedicDTO;

public class ReservationDAO {
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	// 예약 정보 리스트
	public ArrayList<ReservationDTO> reservationList() {
		ArrayList<ReservationDTO> list = new ArrayList<>();
		
		String sql = "SELECT * FROM reservation "
					+ "ORDER BY r_num DESC";
		
		conn = DbConn.getConnection();
		
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				int r_num = rs.getInt("r_num");
				String name = rs.getString("name");
				String resident_num = rs.getString("resident_num");
				String tel = rs.getString("tel");
				String address = rs.getString("address");
				String medic = rs.getString("medic");
				String r_day = rs.getString("r_day");
				String detail = rs.getString("detail");
				
				ReservationDTO dto = 
						new ReservationDTO(r_num, name, resident_num, tel, address, medic, r_day, detail);
				
				list.add(dto);
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return list;
	}
	
	// 예약 정보
	public int reservationInsert(ReservationDTO dto) {
		String sql = "INSERT INTO reservation "
				+ "VALUES(reservation_seq.nextVal,?,?,?,?,?,?,?)";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getResident_num());
			ps.setString(3, dto.getTel());
			ps.setString(4, dto.getAddress());
			ps.setString(5, dto.getMedic());
			ps.setString(6, dto.getR_day());
			ps.setString(7, dto.getDetail());
		
			n = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return n;
	}
			
	// 예약 정보 삭제
	public int deleteReservation(int r_num) {
		String sql = "DELETE FROM reservation WHERE r_num = ?";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, r_num);
			
			n = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}		
		return n;
	}
	
	// 예약 정보 불러오기
	public ReservationDTO getReservationInfo(int r_num) {
		ReservationDTO dto = null;
		
		String sql = "SELECT * FROM reservation "
					+ "WHERE r_num = ?";
		
		conn = DbConn.getConnection();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, r_num);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				dto = new ReservationDTO();
				dto.setR_num(rs.getInt("r_num"));
				dto.setName(rs.getString("name"));
				dto.setResident_num(rs.getString("resident_num"));
				dto.setTel(rs.getString("tel"));
				dto.setAddress(rs.getString("address"));
				dto.setMedic(rs.getString("medic"));
				dto.setR_day(rs.getString("r_day"));
				dto.setDetail(rs.getString("detail"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		
		return dto;
	}
	
	// 예약 정보 수정
	public int updateReservation(ReservationDTO dto) {
		String sql = "UPDATE reservation SET medic=?, r_day=?, detail=? WHERE r_num=?";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		
		try {
			ps = conn.prepareStatement(sql);
						
			ps.setString(1, dto.getMedic());
			ps.setString(2, dto.getR_day());
			ps.setString(3, dto.getDetail());
			ps.setInt(4, dto.getR_num());
			
			n = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return n;
	}
}