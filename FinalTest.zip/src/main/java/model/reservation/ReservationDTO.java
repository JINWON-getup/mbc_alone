package model.reservation;

public class ReservationDTO {
	private int r_num;
	private String name;
	private String resident_num;
	private String tel;
	private String address;
	private String medic;
	private String r_day;
	private String detail;
	
	public ReservationDTO() {}

	public ReservationDTO(int r_num, String name, String resident_num, String tel, String address, String medic,
			String r_day, String detail) {
		super();
		this.r_num = r_num;
		this.name = name;
		this.resident_num = resident_num;
		this.tel = tel;
		this.address = address;
		this.medic = medic;
		this.r_day = r_day;
		this.detail = detail;
	}
	
	public ReservationDTO(String name, String resident_num, String tel, String address, String medic,
			String r_day, String detail) {
		super();
		this.name = name;
		this.resident_num = resident_num;
		this.tel = tel;
		this.address = address;
		this.medic = medic;
		this.r_day = r_day;
		this.detail = detail;
	}

	public int getR_num() {
		return r_num;
	}

	public void setR_num(int r_num) {
		this.r_num = r_num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getResident_num() {
		return resident_num;
	}

	public void setResident_num(String resident_num) {
		this.resident_num = resident_num;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getMedic() {
		return medic;
	}

	public void setMedic(String medic) {
		this.medic = medic;
	}

	public String getR_day() {
		return r_day;
	}

	public void setR_day(String r_day) {
		this.r_day = r_day;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

	@Override
	public String toString() {
		return "ReservationDTO [r_num=" + r_num + ", name=" + name + ", resident_num=" + resident_num + ", tel=" + tel
				+ ", address=" + address + ", medic=" + medic + ", r_day=" + r_day + ", detail=" + detail + "]";
	}
}