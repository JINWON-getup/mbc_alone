package model.medic;

public class MedicDTO {	
	private String name;
	private String medic;
	private String room_num;

	public MedicDTO() {}
	
	public MedicDTO(String name, String medic, String room_num) {
		super();		
		this.name = name;
		this.medic = medic;
		this.room_num = room_num;
	}
	

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMedic() {
		return medic;
	}

	public void setMedic(String medic) {
		this.medic = medic;
	}

	public String getRoom_num() {
		return room_num;
	}

	public void setRoom_num(String room_num) {
		this.room_num = room_num;
	}

	@Override
	public String toString() {
		return "MedicDTO [name=" + name + ", medic=" + medic + ", room_num=" + room_num + "]";
	}
}