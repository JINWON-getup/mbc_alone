package model.medic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.DbConn;
import model.doctor.DoctorDTO;

public class MedicDAO {
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	// 진료과 리스트
	public ArrayList<MedicDTO> medicList() {
		ArrayList<MedicDTO> list = new ArrayList<>();
		
		String sql = "SELECT * FROM medic "
					+ "ORDER BY medic DESC";
		
		conn = DbConn.getConnection();
		
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				String name = rs.getString("name");
				String medic = rs.getString("medic");
				String room_num = rs.getString("room_num");
				
				MedicDTO dto = 
						new MedicDTO(name, medic, room_num);
				
				list.add(dto);
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return list;
	}
	
	// 진료과 정보
	public int MedicInsert(MedicDTO dto) {
		String sql = "INSERT INTO medic "
				+ "VALUES(?, ?, ?)";
			
		conn = DbConn.getConnection();
		
		int n = -1;
		
		try {
			ps = conn.prepareStatement(sql);			
			
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getMedic());
			ps.setString(3, dto.getRoom_num());
			
			n = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return n;
	}
	
	// 진료과 정보 불러오기
	public MedicDTO getMedicInfo(String medic) {
		MedicDTO dto = null;
		
		String sql = "SELECT * FROM medic "
					+ "WHERE medic = ?";
		
		conn = DbConn.getConnection();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, medic);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				dto = new MedicDTO();
				dto.setName(rs.getString("name"));
				dto.setMedic(rs.getString("medic"));
				dto.setRoom_num(rs.getString("room_num"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}		
		return dto;
	}
	
	// 진료과 정보 수정
	public int updateMedic(MedicDTO dto) {
		String sql = "UPDATE medic SET name=?, room_num=? WHERE medic=?";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getRoom_num());
			ps.setString(3, dto.getMedic());
			
			n = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return n;
	}
	
	// 진료과 정보 삭제
	public int deleteMedic(String medic) {
		String sql = "DELETE FROM medic WHERE medic = ?";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, medic);
			
			n = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}		
		return n;
	}
}