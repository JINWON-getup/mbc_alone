-- 관리자 정보
drop table administrator;
create table administrator(
    id varchar(20) not null,
    password varchar2(20) not null,
    name varchar2(20) not null,
    email varchar2(50) not null
);
insert into administrator values('test', 'test', '홍길동', 'test@gmail.com');
commit;

select * from administrator

-- 회원 정보
drop table patient;
create table patient(
    id varchar2(16) unique not null,
    pw varchar2(18) not null,
    name varchar2(50) not null,
    tel varchar2(15) not null,
    email varchar2(30) not null,
    addr varchar2(100) not null,
    rdate timestamp not null
 );
 
 select * from patient;
 
 -- 의료진
drop table doctor;
create table doctor(
    dno number primary key,
    name varchar2(50) not null,
    medic varchar2(30) not null,
    room_num varchar2(30) not null,    
    tel varchar2(15) not null
 );
create sequence doctor_seq;

select * from doctor;

-- 진료과
drop table medic;
create table medic(
    name varchar2(50) not null,
    medic varchar2(30) unique not null,
    room_num varchar2(30) not null
 );
 
select * from medic;

 
-- 예약 정보
drop table reservation;
create table reservation(
    r_num number primary key,
    name varchar2(50) not null,
    resident_num varchar2(30) not null, 
    tel varchar2(20) not null,
    address varchar2(30) not null,
    medic varchar2(30) not null,
    r_day varchar2(30) not null,
    detail varchar2(300) not null
 );
create sequence reservation_seq;

select * from reservation;