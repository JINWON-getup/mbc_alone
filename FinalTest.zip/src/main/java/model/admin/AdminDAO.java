package model.admin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.DbConn;

public class AdminDAO {
	public static final int ADMIN_LOGIN_SUCCESS = 1;
	public static final int ADMIN_LOGIN_PWD_FAIL = 1;
	public static final int ADMIN_LOGIN_ID_NOT = 1;
	
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	// 관리자 확인
	public int adminCheck(String id, String pwd) {
		String sql = "SELECT password FROM administrator WHERE id=?";
		
		conn = DbConn.getConnection();
		
		int n = 0;
		String dbPwd;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				dbPwd = rs.getString("password");
				if(dbPwd.equals(pwd)) {
					n = ADMIN_LOGIN_SUCCESS;
				} else {
					n = ADMIN_LOGIN_PWD_FAIL;
				}
			} else {
				n = ADMIN_LOGIN_ID_NOT;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		
		return n;
	}
	
	// 관리자 정보 불러오기
	public AdminDTO getAdminInfo(String id) {
		String sql = "SELECT * FROM administrator WHERE id=?";
		
		AdminDTO dto = null;
		conn = DbConn.getConnection();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				dto = new AdminDTO();
				dto.setId(rs.getString("id"));
				dto.setPassword(rs.getString("password"));
				dto.setName(rs.getString("name"));
				dto.setEmail(rs.getString("email"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return dto;
	}
}