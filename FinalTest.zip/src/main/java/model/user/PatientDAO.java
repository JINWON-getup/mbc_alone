package model.user;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;

import model.DbConn;

public class PatientDAO {
	public static final int MEMBER_LOGIN_SUCCESS = 1;
	public static final int MEMBER_LOGIN_PWD_FAIL = 0;
	public static final int MEMBER_LOGIN_ID_NOT = -1;
	
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
	
	// 회원 정보
	public int userInsert(PatientDTO dto) {
		String sql = "INSERT INTO patient "
				+ "VALUES(?,?,?,?,?,?,sysdate)";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, dto.getId());
			ps.setString(2, dto.getPw());
			ps.setString(3, dto.getName());
			ps.setString(4, dto.getTel());
			ps.setString(5, dto.getEmail());
			ps.setString(6, dto.getAddr());
		
			n = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return n;
	}
	
	// 회원 검사
	public int userCheck(String id, String pwd) {
		String sql = "SELECT pw FROM patient "
				+ "WHERE id = ?";
		
		conn = DbConn.getConnection();
		
		String user_pw;
		int n = -1;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				user_pw = rs.getString("pw");
				
				if(user_pw.equals(pwd)) {
					n = MEMBER_LOGIN_SUCCESS;
				} else {
					n = MEMBER_LOGIN_PWD_FAIL;
				}
			} else {
				n = MEMBER_LOGIN_ID_NOT;
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}		
		return n;
	}
	
	// 회원 정보 불러오기
	public PatientDTO getUserInfo(String id) {
		PatientDTO dto = null;
		
		String sql = "SELECT * FROM patient "
					+ "WHERE id = ?";
		conn = DbConn.getConnection();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				dto = new PatientDTO();
				dto.setId(rs.getString("id"));
				dto.setPw(rs.getString("pw"));
				dto.setName(rs.getString("name"));
				dto.setTel(rs.getString("tel"));
				dto.setEmail(rs.getString("email"));
				dto.setAddr(rs.getString("addr"));
				dto.setRdate(rs.getTimestamp("rdate"));
			}			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		
		return dto;
	}
	
	// 회원 리스트
	public ArrayList<PatientDTO> patientList() {
		ArrayList<PatientDTO> list = new ArrayList<>();
		
		String sql = "SELECT * FROM patient "
					+ "ORDER BY rdate DESC";
		
		conn = DbConn.getConnection();
		
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				String id = rs.getString("id");
				String pw = rs.getString("pw");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String tel = rs.getString("tel");
				Timestamp rdate = rs.getTimestamp("rdate");
				
				PatientDTO dto = 
						new PatientDTO(id, pw, name, tel, email, tel, rdate);
				
				list.add(dto);
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return list;
	}
	
	// 회원 정보 수정
	public int updatePatient(PatientDTO dto) {
		String sql = "UPDATE patient SET pw=?"
					+ ", tel=?, email=?, addr=? "
					+ "WHERE id = ?";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, dto.getPw());
			ps.setString(2, dto.getTel());
			ps.setString(3, dto.getEmail());
			ps.setString(4, dto.getAddr());
			ps.setString(5, dto.getId());
			
			n = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return n;
	}
	
	// 회원 정보 삭제
	public int deletePatient(String id) {
		String sql = "DELETE FROM patient WHERE id = ?";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, id);
			n = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}		
		return n;
	}
}