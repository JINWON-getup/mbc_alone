package model.doctor;

public class DoctorDTO {
	private int dno;
	private String name;
	private String medic;
	private String room_num;
	private String tel;
	
	public DoctorDTO() {}

	public DoctorDTO(int dno, String name, String medic, String room_num, String tel) {
		super();
		this.dno = dno;
		this.name = name;
		this.medic = medic;
		this.room_num = room_num;
		this.tel = tel;
	}
	public DoctorDTO(String name, String medic, String room_num, String tel) {
		super();		
		this.name = name;
		this.medic = medic;
		this.room_num = room_num;
		this.tel = tel;
	}

	public int getDno() {
		return dno;
	}

	public void setDno(int dno) {
		this.dno = dno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMedic() {
		return medic;
	}

	public void setMedic(String medic) {
		this.medic = medic;
	}

	public String getRoom_num() {
		return room_num;
	}

	public void setRoom_num(String room_num) {
		this.room_num = room_num;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	@Override
	public String toString() {
		return "DoctorDTO [dno=" + dno + ", name=" + name + ", medic=" + medic + ", room_num=" + room_num + ", tel="
				+ tel + "]";
	}
}