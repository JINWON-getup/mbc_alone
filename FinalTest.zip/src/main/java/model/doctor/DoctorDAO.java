package model.doctor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.DbConn;

public class DoctorDAO {
	private Connection conn;
	private PreparedStatement ps;
	private ResultSet rs;
		
	// 의료진 정보
	public int doctorInsert(DoctorDTO dto) {
		String sql = "INSERT INTO doctor "
					+ "VALUES(doctor_seq.nextVal, ?, ?, ?, ?)";
				
		conn = DbConn.getConnection();
		
		int n = -1;
		
		try {
			ps = conn.prepareStatement(sql);			
			
			ps.setString(1, dto.getName());
			ps.setString(2, dto.getMedic());
			ps.setString(3, dto.getRoom_num());
			ps.setString(4, dto.getTel());
			
			n = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return n;
	}
	
	// 의료진 정보 불러오기
	public DoctorDTO getDoctorInfo(int dno) {
		DoctorDTO dto = null;
		
		String sql = "SELECT * FROM doctor "
					+ "WHERE dno = ?";
		
		conn = DbConn.getConnection();
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, dno);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				dto = new DoctorDTO();
				dto.setDno(rs.getInt("dno"));
				dto.setName(rs.getString("name"));
				dto.setMedic(rs.getString("medic"));
				dto.setRoom_num(rs.getString("room_num"));
				dto.setTel(rs.getString("tel"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}		
		return dto;
	}
	
	// 의료진 리스트
	public ArrayList<DoctorDTO> doctorList() {
		ArrayList<DoctorDTO> list = new ArrayList<>();
		
		String sql = "SELECT * FROM doctor "
					+ "ORDER BY dno DESC";
		
		conn = DbConn.getConnection();
		
		try {
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				int dno = rs.getInt("dno");
				String name = rs.getString("name");
				String medic = rs.getString("medic");
				String room_num = rs.getString("room_num");
				String tel = rs.getString("tel");
				
				DoctorDTO dto = 
						new DoctorDTO(dno, name, medic, room_num, tel);
				
				list.add(dto);
			}			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return list;
	}
	
	// 의료진 정보 수정
	public int updateDoctor(DoctorDTO dto) {
		String sql = "UPDATE doctor SET medic=?, room_num=?, tel=? WHERE dno=?";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		
		try {
			ps = conn.prepareStatement(sql);
			
			ps.setString(1, dto.getMedic());
			ps.setString(2, dto.getRoom_num());
			ps.setString(3, dto.getTel());
			ps.setInt(4, dto.getDno());
			
			n = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}
		return n;
	}
	
	// 의료진 정보 삭제
	public int deleteDoctor(int dno) {
		String sql = "DELETE FROM doctor WHERE dno = ?";
		
		conn = DbConn.getConnection();
		
		int n = -1;
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, dno);
			
			n = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DbConn.dbClose(rs, ps, conn);
		}		
		return n;
	}
}